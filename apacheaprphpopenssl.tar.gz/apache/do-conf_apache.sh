#!/bin/sh

./configure \
  --prefix=/usr/local/apache2 \
  --with-mpm=prefork \
  --enable-modules=none \
  --enable-mods-static="unixd status version autoindex dir mime mime_magic log_config filter alias socache_dbm dbd auth_basic authn_core authn_file authn-dbd authn-socache authz_core authz_user authz_groupfile authz_host authz-dbd reqtimeout rewrite setenvif env expires deflate ssl headers vhost_alias remoteip" \
  --enable-so \
  --with-apr=/usr/local/apr \
  --with-ssl=/usr/local/ssl
