#!/bin/sh

./configure \
  --prefix=/usr/local/apr \
  --with-apr=/usr/local/apr \
  --with-mysql=/usr/local/mysql \
  --with-openssl=/usr/local/ssl
