#!/bin/sh

./configure \
  --prefix=/usr/local/apr
