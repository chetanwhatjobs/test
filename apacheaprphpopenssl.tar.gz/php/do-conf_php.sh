#!/bin/sh

# create configure options
CONF="./configure\
      --sysconfdir=/etc/php\
      --infodir=/usr/local/info\
      --mandir=/usr/local/man\
      --with-gd\
      --with-freetype-dir=/usr/include/freetype2/\
      --enable-gd-native-ttf\
      --enable-calendar\
      --with-curl\
      --with-zlib\
      --with-jpeg-dir\
      --with-png-dir\
      --with-config-file-path=/etc/php\
      --with-mysqli=mysqlnd\
      --with-openssl\
      --enable-mbstring\
      --enable-intl\
      --enable-opcache
     "

# check for binary or Apache module
MODE=$1
case ${MODE} in

    binary)
        CONF="${CONF} \
              --enable-pcntl
             "
        LDFLAGS="-rdynamic -lz -lstdc++"
        LIBS="${LIBS} -lz -lstdc++"
        EXTENSION_DIR="/usr/local/php"
        export LDFLAGS LIBS EXTENSION_DIR
        break
        ;;

    apache)
        CONF="${CONF} \
              --with-apxs2=/usr/local/apache2/bin/apxs
             "
        LDFLAGS="-rdynamic -lz -lstdc++"
        LIBS="${LIBS} -lz -lstdc++"
        EXTENSION_DIR="/usr/local/php"
        export LDFLAGS LIBS EXTENSION_DIR
        break
        ;;

    *)
        echo "please give mode: binary|apache"
        exit
        ;;

esac

# run configure
${CONF}
