#!/bin/sh

./config
