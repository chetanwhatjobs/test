#!/bin/sh

./configure \
  --without-x
